<?php

if (file_exists('tasks.php')) {
    echo "[OK] Tasks File Exist";
} else {
    echo "[ERROR] Tasks File NOT Exist";
    return;
}

function addTask($name, $desc)
{
    $status = "Not finished";
    $tasks = file_get_contents("tasks.php");
    $lines = explode("\n", $tasks);

    // Get the last task ID
    $lastTask = end($lines);
    $lastTaskId = explode(",", $lastTask)[0];
    $newTaskId = intval($lastTaskId) + 1;

    // Create the new task line
    $newTask = $newTaskId . "," . $name . "," . $desc . "," . $status;

    // Check if the last line is empty
    if (empty(trim($lastTask))) {
        // Overwrite the last line with the new task
        $lines[count($lines) - 1] = $newTask;
    } else {
        // Append the new task to the file on a new line
        $lines[] = $newTask;
    }

    // Write the updated tasks back to the file
    file_put_contents("tasks.php", implode(PHP_EOL, $lines));
}

function showTasks()
{
    $file = 'tasks.php'; // Replace with the actual path to your file
    $data = file_get_contents($file);
    $lines = explode("\n", $data);

    echo "\n";
    echo "===== TASK LIST =====";

    foreach ($lines as $line) {
        $taskData = explode(",", $line);
        $id = trim($taskData[0]);
        $name = trim($taskData[1]);
        $description = trim($taskData[2]);
        $status = trim($taskData[3]);
        // Read tasks
        echo "\n";
        echo "===================\n";
        echo "ID: $id\n";
        echo "Task name: $name\n";
        echo "Description: $description\n";
        echo "Status: $status\n";
        echo "===================\n";
    }
}

function finishTask($taskId)
{
    $tasks = file_get_contents("tasks.php");
    $lines = explode("\n", $tasks);

    foreach ($lines as &$line) {
        $task = explode(",", $line);
        if ($task[0] == $taskId) {
            $task[3] = "Finished";
            $line = implode(",", $task);
            break;
        }
    }

    // Save the updated tasks to the file
    file_put_contents("tasks.php", implode("\n", $lines));
}

function deleteTask($taskId)
{
    $file = 'tasks.php'; // Replace with the actual path to your file
    $data = file_get_contents($file);
    $lines = explode("\n", $data);

    $tasks = [];

    foreach ($lines as $line) {
        $taskData = explode(",", $line);
        $id = trim($taskData[0]);

        if ($id != $taskId) {
            $tasks[] = $line;
        }
    }

    $newData = implode("\n", $tasks);
    file_put_contents($file, $newData);
}

function openMenu()
{
    echo "\n";
    echo "===========================\n";
    echo "TASK MANAGER by Ivo\n";
    echo "===========================\n";
    echo "\n";
    echo "1. Add new task\n";
    echo "2. Show tasks\n";
    echo "3. Finish task\n";
    echo "4. Delete task\n";
    echo "5. Exit\n";
    echo "\n";
    echo "===========================\n";

    $option = readline("Option: ");

    switch ($option) {
        case "1":
            $name = readline("Task name: ");
            $desc = readline("Task description: ");
            addTask($name, $desc);
            break;
        case "2":
            showTasks();
            break;
        case "3":
            $id = readline("Task to finish (ID): ");
            finishTask($id);
            break;
        case "4":
            $id = readline("Task to delete (ID): ");
            deleteTask($id);
            break;
        case "5":
            exit;
        default:
            echo "\nError: Invalid option\n";
            break;
    }

    // Return to menu
    openMenu();
}

if (php_sapi_name() != "cli") {
    echo "Error : Solo se puede ejecutar el Script desde CLI\n";
}

openMenu();



