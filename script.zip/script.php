<?php

if (php_sapi_name() != "cli") {
    echo "Error: Este script solo se puede ejecutar desde la línea de comandos (CLI)\n";
    exit(1);
}

$options = getopt('a:s:d:f:h', ['add:', 'show', 'delete:', 'finish:', 'help']);

$tasksFile = 'tasks.php'; // Definir la ruta al archivo de tareas

if (!file_exists($tasksFile)) {
    echo "[ERROR] El archivo de tareas NO existe\n";
    return;
}

echo "[OK] El archivo de tareas existe\n";

$tasks = []; // Almacena las tareas en memoria

do {
    echo "===========================\n";
    echo "GESTOR DE TAREAS por Ivo\n";
    echo "===========================\n";
    echo "a. Agregar nueva tarea\n";
    echo "s. Mostrar tareas\n";
    echo "d. Finalizar tarea\n";
    echo "f. Eliminar tarea\n";
    echo "g. Guardar tareas\n";
    echo "x. Salir\n";
    echo "===========================\n";

    echo "Opción: ";

    $opcion = trim(fgets(STDIN));

    switch ($opcion) {
        case 'a':
            echo "Ingrese el nombre de la tarea: ";
            $nombre = trim(fgets(STDIN));
            echo "Ingrese la descripción de la tarea (opcional): ";
            $descripcion = trim(fgets(STDIN));
            addTask($nombre, $descripcion);
            break;
        case 's':
            showTasks();
            break;
        case 'd':
            echo "Ingrese el ID de la tarea a finalizar: ";
            $id = trim(fgets(STDIN));
            finishTask($id);
            break;
        case 'f':
            echo "Ingrese el ID de la tarea a eliminar: ";
            $id = trim(fgets(STDIN));
            deleteTask($id);
            break;
        case 'g':
            saveTasks();
            echo "Guardado exitoso.\n";
            break;
        case 'x':
            echo "Saliendo del gestor de tareas. ¡Hasta luego!\n";
            break;
        default:
            echo "Opción no válida. Por favor, elija una opción del menú.\n";
    }
} while ($opcion != 'x');

function addTask($nombre, $descripcion)
{
    global $tasks;
    $tasks[] = ["nombre" => $nombre, "descripcion" => $descripcion, "estado" => "No finalizada"];
    echo "Tarea agregada correctamente.\n";
}

function showTasks()
{
    global $tasks;
    if (empty($tasks)) {
        echo "No hay tareas para mostrar.\n";
        return;
    }
    echo "\n===== LISTA DE TAREAS =====\n";
    foreach ($tasks as $index => $task) {
        echo "ID: $index\n";
        echo "Nombre de la tarea: " . $task['nombre'] . "\n";
        echo "Descripción: " . $task['descripcion'] . "\n";
        echo "Estado: " . $task['estado'] . "\n";
        echo "===========================\n";
    }
}

function finishTask($id)
{
    global $tasks;
    if (isset($tasks[$id])) {
        $tasks[$id]['estado'] = "Finalizada";
        echo "Tarea marcada como finalizada.\n";
    } else {
        echo "No se encontró la tarea con el ID especificado.\n";
    }
}

function deleteTask($id)
{
    global $tasks;
    if (isset($tasks[$id])) {
        unset($tasks[$id]);
        echo "Tarea eliminada correctamente.\n";
    } else {
        echo "No se encontró la tarea con el ID especificado.\n";
    }
}

function saveTasks()
{
    global $tasks, $tasksFile;
    $serializedTasks = serialize($tasks);
    file_put_contents($tasksFile, $serializedTasks);
    echo "Tareas guardadas en el archivo $tasksFile.\n";
}

?>
